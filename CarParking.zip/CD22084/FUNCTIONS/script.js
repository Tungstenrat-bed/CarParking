function calculate(){
    var name = document.getElementById('Name').value;
    document.getElementById('employeeName').innerText = name;


    let projectweight =0.5;
    let customerWeight =0.3;
    let teamWeight =0.2;

    var weightCust = document.getElementById('cusRate').value;
    var weightTeam = teamScore*teamWeight;
    document.getElementById('').value;

        var status = document.getElementById(feedback).value;
        var teamFeedback = "";
        if(status=="excellent"){
            teamFeedback = 100;
        }else if (status=="good"){
            teamFeedback = 80;
        }else if (status=="average"){
            teamFeedback = 60;
        }else if (status=="poor"){
            teamFeedback = 40;
        }else{
            teamFeedback="undefined";
        }
        document.getElementById('feedback').innerText = teamFeedback;
      
        // const teamScoreValue = Number(teamFeedbackInput.value);
        // const projectWeight = 0.5;
        // const customerWeight = 0.3;
        // const teamWeight = 0.2;

        // const weightedProjectRate = projectRateValue * projectWeight;
        // const weightedSatisfactionScore = satisfactionScoreValue * customerWeight;
        // const weightedTeamFeedback = teamScoreValue * teamWeight;

        // const performanceScore = weightedProjectRate + weightedSatisfactionScore + weightedTeamFeedback;
        //<form onsubmit="calculate(event)">


}